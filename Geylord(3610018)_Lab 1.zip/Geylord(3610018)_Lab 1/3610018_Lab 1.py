#import libraries
import cv2
#get images from computer names Geylord
original = cv2.imread(r'Geylord.jpg')
#make a copy of the image and name it new
new= original.copy()

#display the original image
cv2.imshow('original', original)
while True:
    #image closes when we press g
    if cv2.waitKey(1) == ord("g"):
        break
        #set values for alpha and beta
alpha = 2
beta = 0
#we apply the set values to the image
bright = cv2.convertScaleAbs(new, alpha=alpha, beta=beta)
#show the new image
cv2.imshow('brighter',bright)
while True:
    #cut the displaying of the new image
    if cv2.waitKey(2) == ord("g"):
        cv2.destroyAllWindows()
        break
